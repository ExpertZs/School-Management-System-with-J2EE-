jQuery(document).ready(function($) {

	$('#msg').html("This is really updated by jQuery. Remember to link to jQuery first!")

});