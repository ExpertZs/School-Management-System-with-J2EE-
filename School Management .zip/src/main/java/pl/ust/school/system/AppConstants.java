package pl.ust.school.system;

public class AppConstants {
	
	private AppConstants() {
	}
	
	public static final String VIEW_SUPPORT = "/support";
	
	
}
